#!/bin/bash
source venv/bin/activate
source .env
python -m storage.influx_writer