#!/bin/bash
source venv/bin/activate
source .env
streamlit run dashboard/opensky_dashboard.py