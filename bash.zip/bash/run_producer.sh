#!/bin/bash
source venv/bin/activate
source .env
python -m ingestion.opensky_kafka_producer